Hilltop Job Board (v1)
======================

You asked for a clean, professional job board that:
- Pulls Google Calendar data (Install calendar for now)
- Shows Today / Tomorrow, a weekly Mon–Fri grid, a monthly grid (Sun–Sat)
- Shows two Google Docs notes areas (Install notes + Hilltop notes)
- Requires no scrolling and auto-updates

This package includes:
- /site        -> static website (HTML/CSS/JS)
- /apps_script -> Google Apps Script proxy that fetches the private ICS and returns JSON

Why the proxy exists
--------------------
TV browsers and static hosting often cannot fetch private Google ICS URLs directly due to CORS/security.
The Apps Script proxy fetches the ICS server-side and returns JSON with CORS headers so any device can load it.

STEP A — Deploy the Calendar Proxy (Google Apps Script)
-------------------------------------------------------
1) Go to https://script.google.com and create a new project.
2) Project Settings:
   - Set Timezone: America/New_York
3) Delete any default code and paste in:
   /apps_script/CalendarProxy.gs
4) Deploy -> New deployment
   - Select type: Web app
   - Execute as: Me
   - Who has access: Anyone
5) Copy the Web app URL (ends with /exec)

STEP B — Point the Website to the Proxy
---------------------------------------
1) Open /site/app.js
2) Find:
   proxyUrl: "PASTE_APPS_SCRIPT_WEB_APP_URL_HERE",
   Replace with your Web app URL from Step A.

STEP C — Host the Website
-------------------------
Option 1 (recommended): GitHub Pages
- Create a GitHub repo
- Upload the contents of /site (index.html, style.css, app.js, assets/)
- Enable GitHub Pages (Settings -> Pages -> Deploy from main branch / root)
- Your board URL becomes: https://<your-org>.github.io/<repo>/

Option 2: Any web host (Netlify, Cloudflare Pages, etc.)
Option 3: Local mini PC later (python -m http.server)

Notes
-----
- Your private ICS URL is effectively a secret. Anyone with it can read the calendar.
  You told me you're ok with that, but keep it in mind.

Refresh behavior
----------------
- Calendar refreshes every 2 minutes by default
- Notes refresh every 10 minutes
- Board re-renders itself just after midnight so Tomorrow becomes Today

Next easy upgrade
-----------------
When you want:
- Month view pulls from Hilltop master calendar instead of install calendar
We add a second ICS in the proxy and a switch in the UI.

