/* Hilltop Job Board - minimal JS for kiosk/TV browsers (ES5-friendly) */
(function(){
  var CONFIG = {
    // 1) Paste your Apps Script Web App URL here after you deploy CalendarProxy.gs
    // Example: "https://script.google.com/macros/s/AKfycbx.../exec"
    proxyUrl: "PASTE_APPS_SCRIPT_WEB_APP_URL_HERE",

    // 2) Google Docs "published to web" URLs (you already provided these)
    installNotesUrl: "https://docs.google.com/document/d/e/2PACX-1vQ9kNiSVt4m74h7nKlwzE5wD2z421mtJV_HqjR1plc5-i_iOv7uDH3LDxGspYopFdf3PnMDn0b25OoR/pub",
    hilltopNotesUrl: "https://docs.google.com/document/d/e/2PACX-1vSEfFYL0rCoTtAznGQSexXQTUZgUEBpdXdG6SHTD3KOdAQSlCQR4wo5JkwoIpQGj4wY9df3s6Ahu0Eg/pub",

    // If you want to show only events tagged a certain way later, we can add filtering.
    timezoneLabel: "America/New_York",

    // Auto-refresh cadence (milliseconds)
    refreshMs: 120000 // 2 minutes
  };

  function $(id){ return document.getElementById(id); }

  function pad2(n){ return (n < 10 ? "0" : "") + n; }

  function formatDateLong(d){
    // Example: Mon, Jan 19, 2026
    var days = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
    var months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];
    return days[d.getDay()] + ", " + months[d.getMonth()] + " " + d.getDate() + ", " + d.getFullYear();
  }

  function formatTime(d){
    var h = d.getHours();
    var m = d.getMinutes();
    var am = h >= 12 ? "PM" : "AM";
    h = h % 12;
    if (h === 0) h = 12;
    return h + ":" + pad2(m) + " " + am;
  }

  function startOfDay(d){
    return new Date(d.getFullYear(), d.getMonth(), d.getDate(), 0,0,0,0);
  }

  function addDays(d, n){
    var x = new Date(d.getTime());
    x.setDate(x.getDate() + n);
    return x;
  }

  function sameDay(a,b){
    return a.getFullYear()===b.getFullYear() && a.getMonth()===b.getMonth() && a.getDate()===b.getDate();
  }

  function mondayOfWeek(d){
    var x = startOfDay(d);
    var day = x.getDay(); // 0=Sun ... 6=Sat
    var diff = (day === 0 ? -6 : 1 - day); // move back to Monday
    x.setDate(x.getDate() + diff);
    return x;
  }

  function isoDateKey(d){
    return d.getFullYear()+"-"+pad2(d.getMonth()+1)+"-"+pad2(d.getDate());
  }

  function httpGet(url, cbOk, cbErr){
    // fetch with XHR fallback for older signage browsers
    if (window.fetch){
      fetch(url, {cache:"no-store"}).then(function(r){
        if(!r.ok) throw new Error("HTTP "+r.status);
        return r.text();
      }).then(function(t){
        cbOk(t);
      }).catch(function(e){
        if(cbErr) cbErr(e);
      });
      return;
    }
    var xhr = new XMLHttpRequest();
    xhr.open("GET", url, true);
    xhr.onreadystatechange = function(){
      if(xhr.readyState === 4){
        if(xhr.status >= 200 && xhr.status < 300){
          cbOk(xhr.responseText);
        } else {
          if(cbErr) cbErr(new Error("HTTP "+xhr.status));
        }
      }
    };
    xhr.send(null);
  }

  function loadNotes(){
    httpGet(CONFIG.installNotesUrl, function(html){
      renderDocHtml(html, $("installNotes"));
    }, function(){
      $("installNotes").innerHTML = "<em>Unable to load notes.</em>";
    });

    httpGet(CONFIG.hilltopNotesUrl, function(html){
      renderDocHtml(html, $("hilltopNotes"));
    }, function(){
      $("hilltopNotes").innerHTML = "<em>Unable to load notes.</em>";
    });
  }

  function renderDocHtml(docHtml, target){
    // Extract just the body content (published docs are a full HTML page).
    var bodyMatch = docHtml.match(/<body[^>]*>([\s\S]*?)<\/body>/i);
    var body = bodyMatch ? bodyMatch[1] : docHtml;

    // Remove scripts/styles
    body = body.replace(/<script[\s\S]*?<\/script>/gi, "");
    body = body.replace(/<style[\s\S]*?<\/style>/gi, "");

    // Google Docs often wraps content in <div class="doc-content">; keep HTML but it's safe-ish.
    // Strip some noisy attributes.
    body = body.replace(/\s(on\w+|style|data-[^=]+)=("[^"]*"|'[^']*')/gi, "");

    // Put it in a container and tighten spacing via CSS.
    target.innerHTML = body;
  }

  function loadEventsAndRender(){
    if(!CONFIG.proxyUrl || CONFIG.proxyUrl.indexOf("PASTE_") === 0){
      $("lastUpdated").textContent = "Set your Apps Script proxy URL in app.js";
      return;
    }
    var url = CONFIG.proxyUrl + "?mode=events";
    httpGet(url, function(txt){
      var data;
      try { data = JSON.parse(txt); } catch(e){ throw e; }
      renderAll(data.events || []);
      $("lastUpdated").textContent = "Updated " + new Date().toLocaleString() + " (" + CONFIG.timezoneLabel + ")";
    }, function(){
      $("lastUpdated").textContent = "Unable to load calendar data (check proxy URL / network).";
    });
  }

  function normalizeEvents(raw){
    // raw: [{startIso, endIso, summary, location, allDay}]
    var out = [];
    for(var i=0;i<raw.length;i++){
      var e = raw[i];
      var s = new Date(e.startIso);
      var en = new Date(e.endIso);
      out.push({
        start: s,
        end: en,
        summary: (e.summary || "").trim(),
        location: (e.location || "").trim(),
        allDay: !!e.allDay
      });
    }
    // Sort by start time
    out.sort(function(a,b){ return a.start - b.start; });
    return out;
  }

  function renderAll(rawEvents){
    var events = normalizeEvents(rawEvents);

    var now = new Date();
    var today = startOfDay(now);
    var tomorrow = startOfDay(addDays(today, 1));

    // TODAY / TOMORROW
    $("todayDate").textContent = formatDateLong(today);
    $("tomorrowDate").textContent = formatDateLong(tomorrow);

    renderDayList(events, today, $("todayList"), $("todayEmpty"));
    renderDayList(events, tomorrow, $("tomorrowList"), $("tomorrowEmpty"));

    // WEEK: Mon-Fri
    var mon = mondayOfWeek(today);
    var fri = addDays(mon, 4);
    $("weekRange").textContent = formatDateLong(mon) + " – " + formatDateLong(fri);
    renderWeek(events, mon);

    // MONTH: Sun-Sat grid
    renderMonth(events, today);

    // Midnight rollover protection (if display stays on)
    scheduleMidnightRerender();
  }

  function renderDayList(events, day, ul, emptyEl){
    while(ul.firstChild) ul.removeChild(ul.firstChild);

    var count = 0;
    for(var i=0;i<events.length;i++){
      if(sameDay(events[i].start, day)){
        ul.appendChild(makeEventLi(events[i]));
        count++;
      }
    }
    emptyEl.hidden = count !== 0;
  }

  function makeEventLi(e){
    var li = document.createElement("li");

    var t = document.createElement("span");
    t.className = "event-time";
    t.textContent = e.allDay ? "All day" : formatTime(e.start);
    li.appendChild(t);

    var s = document.createElement("span");
    s.className = "event-title";
    s.textContent = e.summary || "(No title)";
    li.appendChild(s);

    if(e.location){
      var loc = document.createElement("span");
      loc.className = "event-loc";
      loc.textContent = "• " + e.location;
      li.appendChild(loc);
    }

    return li;
  }

  function renderWeek(events, monday){
    var grid = $("weekGrid");
    grid.innerHTML = "";

    var days = ["Mon","Tue","Wed","Thu","Fri"];
    for(var col=0; col<5; col++){
      var dayDate = addDays(monday, col);
      var box = document.createElement("div");
      box.className = "week-day";

      var hd = document.createElement("div");
      hd.className = "week-day-hd";

      var dow = document.createElement("div");
      dow.className = "week-dow";
      dow.textContent = days[col];

      var dt = document.createElement("div");
      dt.className = "week-date";
      dt.textContent = (dayDate.getMonth()+1) + "/" + dayDate.getDate();

      hd.appendChild(dow);
      hd.appendChild(dt);
      box.appendChild(hd);

      var ul = document.createElement("ul");
      var c = 0;
      for(var i=0;i<events.length;i++){
        if(sameDay(events[i].start, dayDate)){
          ul.appendChild(makeEventLi(events[i]));
          c++;
        }
      }
      if(c === 0){
        var em = document.createElement("div");
        em.className = "empty";
        em.textContent = "—";
        box.appendChild(em);
      } else {
        box.appendChild(ul);
      }
      grid.appendChild(box);
    }
  }

  function renderMonth(events, refDate){
    var label = $("monthLabel");
    var months = ["January","February","March","April","May","June","July","August","September","October","November","December"];
    label.textContent = months[refDate.getMonth()] + " " + refDate.getFullYear();

    var grid = $("monthGrid");
    grid.innerHTML = "";

    // DOW header
    var dows = ["Sun","Mon","Tue","Wed","Thu","Fri","Sat"];
    for(var i=0;i<7;i++){
      var h = document.createElement("div");
      h.className = "month-dow";
      h.textContent = dows[i];
      grid.appendChild(h);
    }

    var first = new Date(refDate.getFullYear(), refDate.getMonth(), 1);
    var start = addDays(first, -first.getDay()); // back to Sunday
    var endMonth = new Date(refDate.getFullYear(), refDate.getMonth()+1, 0); // last day
    var lastGrid = addDays(endMonth, 6 - endMonth.getDay()); // forward to Saturday

    // Pre-index events by date key for quick lookup
    var map = {};
    for(var e=0;e<events.length;e++){
      var k = isoDateKey(events[e].start);
      if(!map[k]) map[k] = [];
      map[k].push(events[e]);
    }

    var cur = start;
    while(cur <= lastGrid){
      var cell = document.createElement("div");
      cell.className = "month-cell" + (cur.getMonth() !== refDate.getMonth() ? " dim" : "");

      var top = document.createElement("div");
      top.className = "month-num";

      var n = document.createElement("span");
      n.textContent = cur.getDate();

      var k2 = isoDateKey(cur);
      var evs = map[k2] || [];
      var badge = document.createElement("span");
      badge.className = "badge";
      badge.textContent = evs.length ? (evs.length + " item" + (evs.length>1?"s":"")) : "";
      if(!evs.length) badge.style.visibility = "hidden";

      top.appendChild(n);
      top.appendChild(badge);
      cell.appendChild(top);

      var list = document.createElement("div");
      list.className = "month-events";

      // show up to 2 summaries
      for(var j=0;j<evs.length && j<2;j++){
        var row = document.createElement("div");
        var dot = document.createElement("span");
        dot.className = "dot";
        row.appendChild(dot);

        var txt = document.createElement("span");
        txt.textContent = (evs[j].summary || "").slice(0, 28);
        row.appendChild(txt);
        list.appendChild(row);
      }
      if(evs.length > 2){
        var more = document.createElement("div");
        more.textContent = "+" + (evs.length - 2) + " more";
        more.style.color = "#475569";
        more.style.fontFamily = "var(--mono)";
        more.style.fontSize = "10px";
        more.style.marginTop = "4px";
        list.appendChild(more);
      }

      cell.appendChild(list);
      grid.appendChild(cell);

      cur = addDays(cur, 1);
    }
  }

  var midnightTimer = null;
  function scheduleMidnightRerender(){
    if(midnightTimer) return;
    var now = new Date();
    var next = new Date(now.getFullYear(), now.getMonth(), now.getDate()+1, 0, 0, 5, 0); // 5 sec after midnight
    var ms = next.getTime() - now.getTime();
    midnightTimer = setTimeout(function(){
      midnightTimer = null;
      loadEventsAndRender(); // re-render for the new day
    }, ms);
  }

  function init(){
    loadNotes();
    loadEventsAndRender();
    setInterval(loadEventsAndRender, CONFIG.refreshMs);
    // notes can refresh less often; but keep simple:
    setInterval(loadNotes, 10 * 60 * 1000);
  }

  document.addEventListener("DOMContentLoaded", init);
})();
